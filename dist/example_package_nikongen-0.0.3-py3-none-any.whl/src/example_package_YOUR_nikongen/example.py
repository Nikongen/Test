def add_one(number):
    return number + 1

class test():
    def __init__(self):
        self._test= 1
        print(self._test)